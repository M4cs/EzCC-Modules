#import "ControlCenterUIKit/CCUIToggleModule.h"

@interface EzSoundcloudOpener : CCUIToggleModule
@property (nonatomic, assign, readwrite) BOOL EzSoundcloudOpener;
@end
